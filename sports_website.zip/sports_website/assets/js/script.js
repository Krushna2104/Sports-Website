document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu');
    const mainNav = document.querySelector('.main-nav');
    
    if (mobileMenuBtn && mainNav) {
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            this.querySelector('i').classList.toggle('fa-bars');
            this.querySelector('i').classList.toggle('fa-times');
        });
    }
    
    // News Filtering
    const newsFilterBtns = document.querySelectorAll('.news-filters .filter-btn');
    const newsItems = document.querySelectorAll('.news-item');
    
    if (newsFilterBtns.length && newsItems.length) {
        newsFilterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all buttons
                newsFilterBtns.forEach(b => b.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                
                const filter = this.getAttribute('data-filter');
                
                newsItems.forEach(item => {
                    if (filter === 'all' || item.getAttribute('data-category') === filter) {
                        item.style.display = 'grid';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });
    }
    
    // Players Filtering
    const playerFilterBtns = document.querySelectorAll('.players-filters .filter-btn');
    const playerCards = document.querySelectorAll('.player-card');
    
    if (playerFilterBtns.length && playerCards.length) {
        playerFilterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all buttons
                playerFilterBtns.forEach(b => b.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                
                const filter = this.getAttribute('data-filter');
                
                playerCards.forEach(card => {
                    if (filter === 'all' || card.getAttribute('data-category') === filter) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }
    
    // Schedule Tabs
    const scheduleTabBtns = document.querySelectorAll('.schedule-tabs .tab-btn');
    const scheduleTabContents = document.querySelectorAll('.schedule-tab-content');
    
    if (scheduleTabBtns.length && scheduleTabContents.length) {
        scheduleTabBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all buttons
                scheduleTabBtns.forEach(b => b.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                
                const tab = this.getAttribute('data-tab');
                
                scheduleTabContents.forEach(content => {
                    if (content.id === tab) {
                        content.classList.add('active');
                    } else {
                        content.classList.remove('active');
                    }
                });
            });
        });
    }
    
    // Schedule Filtering
    const scheduleFilterBtns = document.querySelectorAll('.schedule-filters .filter-btn');
    const scheduleMatches = document.querySelectorAll('.match-item');
    
    if (scheduleFilterBtns.length && scheduleMatches.length) {
        scheduleFilterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all buttons
                scheduleFilterBtns.forEach(b => b.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                
                const filter = this.getAttribute('data-filter');
                
                scheduleMatches.forEach(match => {
                    if (filter === 'all' || match.getAttribute('data-sport') === filter) {
                        match.style.display = 'grid';
                    } else {
                        match.style.display = 'none';
                    }
                });
            });
        });
    }
    
    // Smooth Scrolling for Anchor Links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Set Reminder Button Functionality
    const reminderBtns = document.querySelectorAll('.reminder-btn');
    reminderBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const matchItem = this.closest('.match-item');
            const teams = matchItem.querySelector('.teams').textContent.trim();
            const date = matchItem.querySelector('.match-info p:nth-child(2)').textContent.trim();
            const time = matchItem.querySelector('.match-info p:nth-child(3)').textContent.trim();
            
            alert(`Reminder set for:\n${teams}\n${date}\n${time}`);
            
            // Change button text and style
            this.textContent = 'Reminder Set!';
            this.style.backgroundColor = '#10B981';
            this.style.cursor = 'default';
            this.disabled = true;
        });
    });
    
    // Highlight Button Functionality
    const highlightBtns = document.querySelectorAll('.highlight-btn');
    highlightBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const matchItem = this.closest('.match-item');
            const teams = matchItem.querySelector('.teams').textContent.trim();
            const result = matchItem.querySelector('.result').textContent.trim();
            
            alert(`Redirecting to highlights for:\n${teams}\n${result}`);
        });
    });
    
    // Form Submission Handling (for contact page)
    const contactForm = document.querySelector('.contact-form form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = this.querySelector('#name').value;
            const email = this.querySelector('#email').value;
            
            // In a real app, you would send this data to a server
            console.log(`Form submitted:\nName: ${name}\nEmail: ${email}`);
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.className = 'success-message';
            successMessage.innerHTML = `
                <i class="fas fa-check-circle"></i>
                <h3>Thank You!</h3>
                <p>Your message has been sent successfully. We'll get back to you soon.</p>
            `;
            
            // Replace form with success message
            this.parentNode.replaceChild(successMessage, this);
        });
    }
    
    // Responsive adjustments
    function handleResponsive() {
        // Adjust news item layout for mobile
        const newsItems = document.querySelectorAll('.news-item');
        if (window.innerWidth < 768) {
            newsItems.forEach(item => {
                item.style.gridTemplateColumns = '1fr';
                const img = item.querySelector('.news-img');
                img.style.height = '250px';
            });
        } else {
            newsItems.forEach(item => {
                item.style.gridTemplateColumns = '300px 1fr';
                const img = item.querySelector('.news-img');
                img.style.height = 'auto';
            });
        }
    }
    
    // Run on load and resize
    handleResponsive();
    window.addEventListener('resize', handleResponsive);
});