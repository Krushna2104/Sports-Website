<?php
$currentPage = 'news';
$pageTitle = 'Latest Sports News - Cricket, Hockey & More';
include 'includes/header.php';
?>

<section class="news-page">
    <div class="container">
        <h1 class="page-title">Latest Sports News</h1>
        
    
        <div class="news-list">
            <article class="news-item" data-category="cricket">
                <div class="news-img">
                    <img src="https://www.livemint.com/lm-img/img/2024/11/24/600x338/CRICKET-AUS-IND-127_1732439424393_1732439436032.jpg" alt="Virat Kohli">
                </div>
                <div class="news-content">
                    <span class="news-date">June 1, 2023</span>
                    <h2>Virat Kohli Scores Century in Test Comeback</h2>
                    <p>Virat Kohli marked his return to Test cricket with a magnificent century against England at Lord's, silencing his critics.</p>
            </article>
            
            <article class="news-item" data-category="hockey">
                <div class="news-img">
                    <img src="https://www.hindustantimes.com/ht-img/img/2024/09/18/550x309/The-victorious-Indian-team-after-beating-hosts-Chi_1726625957104.jpeg" alt="Indian Hockey Team">
                </div>
                <div class="news-content">
                    <span class="news-date">May 28, 2023</span>
                    <h2>Indian Men's Hockey Team Wins Asian Championship</h2>
                    <p>The Indian men's hockey team defeated Pakistan in a thrilling final to clinch the Asian Hockey Championship title.</p>
                </div>
            </article>
            
            <article class="news-item" data-category="badminton">
                <div class="news-img">
                    <img src="https://static.toiimg.com/thumb/msid-92932829,width-400,resizemode-4/92932829.jpg" alt="PV Sindhu">
                </div>
                <div class="news-content">
                    <span class="news-date">May 25, 2023</span>
                    <h2>PV Sindhu Reaches Singapore Open Finals</h2>
                    <p>Indian badminton star PV Sindhu advanced to the finals of the Singapore Open after a hard-fought semifinal victory.</p>
                </div>
            </article>
            
            <article class="news-item" data-category="cricket">
                <div class="news-img">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4A5uhdPkSHxPBoNOXAy2hPagrgxC01C_gKw&s" alt="IPL">
                </div>
                <div class="news-content">
                    <span class="news-date">May 22, 2023</span>
                    <h2>Mumbai Indians Win IPL 2023 in Last-Ball Thriller</h2>
                    <p>Mumbai Indians clinched their 6th IPL title after defeating Chennai Super Kings in a match that went down to the final ball.</p>
                </div>
            </article>
            
            <article class="news-item" data-category="other">
                <div class="news-img">
                    <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUQEBIVFRUVFRAVFRYQFRUVEBUVFRUWFhUVFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQFyslICUtLSstLS0tLS0rLS0rLS0rLS4tKy0tLS0tMistLS0rLS0tLS0tLS0tLS0tLSstLS0tLf/AABEIAKcBLQMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAADBAIFBgABBwj/xABAEAACAQMCAwYDBgUCAwkAAAABAgMABBESIQUxQQYTIlFhcTKBkQcUQlKhsWJywdHwI+EzkvFEU1RjgoOissL/xAAaAQADAQEBAQAAAAAAAAAAAAABAgMABAUG/8QALhEAAgIBBAADBgYDAAAAAAAAAAECEQMEEiExE0FhIlFxgaGxFDKRwdHwBTPh/9oADAMBAAIRAxEAPwD5NIKitSlNRjFKYbjotQjWi4pTA2NeBq5xQzTowyrUUUrGaYQ01mPStDZKOBXjLRMKMtRC0yyVDTQAQVaKpqJFQJpTD8b01G9U6y03DLRQaLZTU6QiuhnG59qZSdTtnfyNNaNRJkr2eKNQFzrcjJ0nEcfLG+PGfoB60C9nwMDmf8xXthbELrPNv2pW+aQ6jUdzBFKgwpuRKCy0xKxCVaB3dOyLQwtIzC4jpiJKn3deigmYZiWjhaWjejq9GzEZVpGaOrE1Fos0GEqVSmolozQVwXFZBCRii5oIaoSS09gCvJSkzUOSahd5SsNA50pJ46sGNLstYwljNNQRV0MNPwRUrYDyOGi9xTKLRAKCMINb0vJDVuy0tNHVAorSteo1FkShpHWGDxmiV0cVFEVMhQJWhstNMlDZaxhRlqJiPM7D1pgrSF+xG5PsNvmTSsKC61QaiMk8s4x74pGW4LbnPsOdKyyMxyx9PlQSSKxrG1u2HUD0xt+tWHDj3mSTsPizn6A0lwvh8k5OgeFca3IOhATgZPmeg5n5Ei8trQlktYBqZmCjnlnY4ycZP0zQbofHHc/Qi0wyC3LPL08vnt9fWr63nDKGHI1u5+wPDvu6RSMC4bR30cpSR3BJlG7FSwIfCkbYA6VnbrsDNaBnhkFxCctjZbiMb/GgJDDGPEp9cAUVFoXJNTKWRaWlFONS0ookhCSorRJBXiClaGCKteNHRoxRdFbaYS01JDTTQ0Ix1mgBI6YVaBHtTKGsAg6Uu608aWmWsMV8rUpLLTVwlV8wrBPNVERaAlOQCjQ1nvd1ExU/HHXphrUAThhpkJiiIlcwqQpDNEQ0BqNAKaIQ+ihyRU5EtTaGnYCmeGpRW1WYt6PHbVkg2V6W9EMVWBgockdOArZEpdlp+RaWdaFmFSOn61QXkuX9Bnb03/tWklGAT6Gs40JIJPQbmgxkKlt/8wKPwvhr3Mywx82O5IJCqPiYjyA/oOtLpzradhIxCj3r7bMqDoxyN/lillJJWwFjx+0jtIY7eFQuASx5sxP4nPVvbboNgKvuxXDRZRLfXCf6srxiJGKhjbnBeRcnKncNk/lVdtVZMcSR5jPcDUkfjKnk7fhU+5oN12muLh/BpVsKC+MIirySNTnAG+3r5kmpqba3UXjHjb+p9Pu+KPIW0ExKx8Qg1IG9WcYJb1GMjGRtVFPaW0OZ2gj2y2UjQSlvMPjIPrzrEJMyMC00zn82WC/9K2sM5nhK6fFpBAPIkbg1zyk7ts6Y41VJFLI5l1TLE6ITnxuHYdMk/Fv5tnc8zSzrTP3GdJYwhBL6w6hjqUAgFHXO2QTtg8sbUO4iKMyOMMpIIPmK68cm+zjy41Horpkqdlw+WXPdRs+OekU9ZWXeuE1Bc82PICtfHw1YkAgkGR+Y41HzpcmTZ12HFi399GHe3eM6ZFZT5MCDRUFame+YNpu4GMf5sa4/fI3FCj7PxyHVDJ4TuFO5+RoQzxfDGyaaS5XJRpHUJYK1kHZcdZCP89qWv+zUi/AwcevhP9qruTIPHJGRcYrhJR76FkYqwII5g86QkegLQ4slemk4pKbjNZGATxVWXUdXMtVt2KajWVYFO21JybUa3krBsuYRR9FJQTUx31BmAq1EC0pA9WEIzU0jAhBmjwwU3DHRwlUjE1g4oqZ7qpItMIKegC4hqWmivQHasY8elZjU5JaTmlpWzAZWpZ2r2R6AzUqMEzSl/b6kOOpBPy5/tTC0zbwM7BEBZmIVQOZJ2AFNxXITK8K4YZ5dA2Vd3foq5/c8hV/xa8AVYoxhFAVQPoK03HuBR2dusULDvCWack4DN5Ln8K4IHnz61jLa2kkPeAAgA4AdNXocE9a5Y6jHlVxZ04oWrBNHnw7+EBmB6MRsNvr86sbOwk7sKikA7k45/Wq3hDkSnveb5Jz1NbiwnwADjApMsqZ04VcbohBwJWdZlQowVF06s7jHiLc8nG4z5+dWM9wttJl20qoJZjsMDA29ckbVYWl0pO36UHjsUJKlhk4OxOVIPNSvIj0pW93ZSlAJw3tHBMyNFrMhJCvpGAFG+rIwVxgfP6e9sbIPGl2ANWe7kwMZ2OhiPlj5jyqtteLxQEBZNLDGFiHiG/LA2+VXUvFRcQSxspGU1AmNo9TKQw2Yc9unnVcTp9kM8Lj0VnZhoVyJBhm/ERnYdBXca4ZMB3tqQyE7+nyNOWvDQ9upXnuTj4s+dZw8YuI/BnJUkEcj86nm5kymni9qos7bjVwq6TGDjmEO/wDymj8K4jEWaSNu7b8S8tRHPwnkaZ4XxDvNJ7rGMam55qm43xCKN8KAcFs45gk5NIuCzpcUahOPZIBH1p5L5WGP+lYKDjCN19jVrbz5AwadTZzvGhrtRw7WurbI5Hy9D/Cf0r59NzrWX/EWXKMeh+YxmspJvvXRjluOXNCmiERp+I0iq01EaqQDuKQuUp3NLzJmtYClnShLtVhNDQGhoNhR7FNRxPSenFRLUBhi3lq3tHrOQyb1b2021FGovEkovfVUfea9W6pwUXUc1GWaqWO4ppJqNgofeWlpZKGZaXd6DZiUktLO1TxUWSkCLPUNNNCGipb1gCsaVuuzNiLSH7/MPG4IhB5qpGO8925D096r+y/AllcyzbQRYMhPJj0j+fX09xRe1/G++cxryHlyArzNbnlOXgY+338BoQ3P0M/xi4Nyzl+RyM53xVdw7hq6WTbvQuFzkbj4WU+o6eYPmKcJpDitwUVZAcENgHpurAah1XOMiuuGmjDGoRL48+2d+XR7ecMZUXWp1Kc68HQxOeTcuRxj0o9lMcbUpc9p53j7ho0UMNJZAdyRnG/IkUrb3RUDNRcWuGdqkpcxNVDeFdycUSK7ilY6st5oCVz7kdPSs2eKA7GoNxBVwY9j5igohZvYhEABHEkfXCgL9fOjz3y6S7yeFOY9t/2H61gJ+0jMMMNx1FUvEOJu6lcnSSNXrVYRbdEMkqVm77G9o5WlKoMqAGI/gzy9zQu2KzCT7zFFpicDXkDZs4yRzG3Wl+wJCoXHNmOT6L4QP3+tariHEVKFGwQRgg9RR1El4jpDafcooU7OxyhO8JBGMkDIOPP1rKcYtUMjOGOWJJzuK1vDeNxxRkE7gMB6jG1YG8mLMTUkdElzYIHSdjT9rxZ15naqzRUlWmFaLpbxpNTnkFP1O39aT11JXwmnz5+w5ClnaujEqRw53chhXoyNVeJKZhkqhzMfWjCHNChp+IVhRF7WlJber4pS00NBoKM7NFSjpV3cxVWyR71kEqQachnpVlrlrIeTH+/qQkNLxrTkMNFsSxm3anY3peOLFFrJhDGSuU0vmiRGg2ahpFzR1t6jAKtLeKskKJx2tPcP4Y0rrEg3Y9eQHVj6AUwIKseJXy8Ptz/4iUb+aL0X+p9fap6jK8cairk+v76GScnSF+1XGlt0WytugxkfEzH4mP8An7VkQuBuck7k+tRtUZiZ5N2blnoPOhXMtR02mWJbnzJ9svOktkfmRd6rO0DZgb3T/wCwo8ktDlQOpRuRrrRJoRsbozQ92wJ0FckEAsACV36EBTv6CmLIa10uMMMA5HPyNaDhFiLC0Nyy638bxjALO7rogUL1XBaQkflI61liZYlSWZmZ3cA6zkqgB8PoTzwPyilyQ3Ljsrhy7Jc9ErmxZTtuKlBwxn64/WtHZW4lTYjOM+4qpuIWQkbjFcamejsK6ayKnSNyatezHCVe5SJwDhHkII2yCoHvgtQ+HsWkLOM4wMeeTyz6/wB6vuBLp4gmd9ULj3JYH/8ANLkk/DlXdN/QlKPK+KDaQjuqjG+rAGOfP9c1XcSnODvV/wBoISoglxhX72M/zBmdB8wJPoKo7yLIqWF3ji/Qsny17uDOveN8JNQ7yi3VkSdqWe1deddKpittBddaLgPCBIpGod4QdAOy52OPnyz61lkQ5649K1HBAykFTQboVrchK6jKkqwIIJBB2II2IIpCSt12tsRLELtR410rL/EvJX9wcD2I8qxbx11xluVnDKO10xM0zbivRBTlvb0yROQzbCrGCl4oqOpxTUIH1UNzQnloJmpWaiN0tVcq70/LJSUp3pbCVMkdSht6c7nJpu3t6dIDIW9nT0NrT1pBTnc1mhStMFAkSrWRaTlWpDIrXr2J6lOlASiNZb2zVc2jVnbZ60HClB3bZVGWP9B6mqRE7LqK5S3jNzL0z3anqw/F7D9/asXHrvZ2nlzoB+vkBU+KXT3kwRdkGwx8KqK0EECxoEQYA/U+dIoJ5G/P7en8nT/qj6sqr1cVmr9t603EGrNXozVJE4Fb3lWvBOFzXL93BGXIxqPJEHm7HZR/govZrs6bmQliUhQjvHHP+RPNj9BzPQH6hbBY4xBbIEjHIL19WJ3Zj5moymolFj3FHP2aLBDeXgJRFRUgjLKqgAABiVHQdOlYrtW8MTNDEzOFVGLOoUhi2wUZOTy32519MltGbmaydh2M+/vcTOxWPvNCFCA5MbhScFSNOkH50FqYY4vJkdJfc08PSj2ZvhlwwUSLtktt5bkY9hVnd2/ep3i88b+3maMeCMt7d2sKZWNkKrk5AKLjc7nIINeW9oVYRyfASQN8rqB3rjyNN2unyvg+TvxO4IQ4fD4tuS9fNurf2ot5ffd7mKbGcIcjrg6hkeu+flVo1kY3yB4TgbDYY51QdsJAZgB+GNM/NiT+lX0uNTm4y6p2T1M9sNy7tH1aztbe/wCH92r5Vhp1L8ccitlWI5ghgDg8wfI18yulkike2uV0zRnDD8LDo6eakb0Ds+1zCHu4GMSxrlnb/hSdFhwdpCxOMdNztjNbF7i343EFLLb8QiB0H8Eg54B5sh6jmp33G5rj/wAesalGMrXl6P1OSOpkp7mu+zLWagmrC6s1dcY25GqqISQzG3uUMcq81bkR0ZT1B8xWls8MMVyThKEqZ3qamrRio4TE5jce3qOhFaPhtr1FWF7wpZBhhuPhPUV5YWrR+E0rdmT4LW3TWjRHkysp+YxWB0edfSrePYEVg+JxaZ5V8pH+hOR+hrqwe45M/vARw07DDULcU/EldSOVsgEoM21PFKTuRRAV08lLtNUrkGk3U1NjBmmoDyUF2xUNdLRi0hTerG3iqMcFOQJVUKMQLiiO1QVqFNJWbAQkkoDmgzTVBJqjINE3jzSskOKdU1GUUEAWtVLMFUZJOBVtxBiFFvGf5j5t1NG4fw/u071tmYbZ/Cp/qaSuZwuw+I/oPOlyahxfhY/zP6IvjiorfIe4bEsYwvPqaallqpt56ZMtdMIKEaRBycnbA3bZqlnSreXervhPZY7TXHhA3EZ+I+WryHpz9qE2kuSsEN8Fg0RJENtIBb1dt2z8zj5VdRkCs5e3fdSDqpznzBPX2p6K7zXA3bs7lGkXqSj0pfsKdPDhIOYmuFfrj/VbfHsRSQuCKY+zibJvrRuk5kA/guE6fNDUtTHfp5x+D/b9ycnslGXkZrtdcwxcQhuX0uJE0TBgDpwQqOffl/6K0dzbwyIBoUeWkAexGK+W8duTJLKZDkF3X0AUlVx6YFXnZjtPFHFoupAO72Utksy9MAbkjlt6V2/g5Y9PBdtKn/fTonHPF5JVwr4NVeaIoWZ28KAksfL+pr5VcXfeyvK42dvhPLTyCn5YFPdq+1rXjCOMFIFOQp+KQjkz+nkvz58qlU2rs0eDYrfZHPl3cLo3sV0GjjveITFgmGSMBDAviUBFi/GxHeA89AGSMkEYi+YiTWi91vqURsToYc9DAkrhgcDJK7DJxkn4fdopzIemB4nUjBjzpZQQPCG6b7DcUvxK971tXv0Ublid9IA5ELnmQorpjFR4RzI3XBeN2/E0Wy4nhZxtBcrhWZuQBPIOdvRvQ4oHELC64ccXCmWDpPENgP8AzF/Cff5E1gK+q9hO3hdBaXeXcDCOSMyIB8L55sB16jnuCTDPCG1uS4+w6yvHymT4TeRzDMbq3mAdx7jmKtHtwaXvuzXDpzqEMkLnk1sQm/om6/QUs/YNh8N7d6fV98dOXp6V5M3p1yp/Rt/QtDXKXkOCZYgTIyqo6uQF+prB8SuxLNJMvwu7FfUDCj9q23DPs5gLd5cNLLg7CV9jjzwAcfOqj7ROGRwSwiJURWh+CMBQNDnfSPPWP+WurTbGntt/Kv8Aok9T4jqihtnqzheqa3NWUTVWwDxNLTLU1apEZoWArJLfNAktKuhFUXhpkg2Za5t6SKVpLu3qqkh3pWjI1a2+1e9zinok2ohhp2gFU60pPVzJBSsttU2Yzs4OaGMirqWzpV7Wl2lEwcBzWh7P8I7wmWT/AIaefJm8qV4Fwdp5BGuw5s3RVHM1f9oL5UC2sAwo225n1PrXBrNU8XsQ/M/oCMd0qKnjF8GJx8K/qelZecnJJ5mr6eHbFVVzFVtHpvCjcvzPsM5XwugUUtP2ELysI41JJ+gHmT0FJ8NsWlk0LsObMeSjz/2rXpKkCd3EMDqfxMfNjXTPKoDY8TkO2FnDajUcSS/mPwqf4B/XnVdxbtFnIzVZczySHC/U8qW7uOP411P55yBXHObl2d0MSiDld5Dk1BeJmFgHOAeRP7UhxLi7jIjTHqaztzO7nxk/OtGNlHwfUbTiAcbHNMdnpGXiEgQ6TNZS6eg72FgVJ+TGvlvDL6SM+BtvI8v9q3XZ7iSy3dk58OZJYX88Twuo/wDkF+eKriit+2XKZDOrg2jCpJsPIgUCePOx+VHniMbNG3NGZG/mUlT+oqHoflXvPk8oDbMinBGD67g0zKDzpWaPO1McJgmkcQxRtKTyVBlgPMnkB6nakTrhhANvt15j3FWHZnh63VzFbtIY1kYjUACdlLYGdsnGAfMjY8qvrrsBfwKLlVik0aZNEbd5INJDeJCul+W6gnPrSnaUgSw8WtFxHOwl0r8MV3GQ0sRPQFhrHmGONhSt+4Jru1P2aJ3Yk4fnWgw0Ttq7zHVWPJ/TYHbGOvzAlkbqrKfVWVlPUHcEEfLFfd7qOeSa1vLFk7uRAJ1kJCPAwDowwCda6nxjq++2aV7b9iY71Xlg0rdIOhAEuBkJL5NjGGPpnblOMvJmaBfZ9xdLmDUcd8mFlHln4XUdFYA/MMOla9a/O3BeLTWkvewtpYZVlO6MM7o46jb5dK+rN9olsLMXA3mJKi3z4xJ6npH11/LntXkv/Hzx6lzhzFr9PT+CU4rakkaHtD2jis4u8mOSciOMfHI3kPIcsnkPoD8V4hxeS5uDcTHxP4cD4UX8KL6D+pPMmkOKcTluZWnnfU7fJVHRUX8Kjy+ZySTQkNezgwqC57DGNF9bin46rraTIB8xTyPXHONNoshkGjI1JGSvUmpEGi0QV7ItJpc1M3FPZqBTrVZNDvVi75oejNTkzIuLacYp6N81lLK9q5gutqtZmixfFCYCgG4qJnpaBQRkpf7sWIVRkk4AHMmi97V/wmJIYjcybsc92Pyj83uf2qOo1EMEN0ggZ75LK0VVHjkAZyME5PIbdAMVRWu/+o3Nv0FBurnvpCx5A8untVjw+2aTlsOpPIVx6bEsuR6iS+BWXsrau/MBMlCTgskg1YCp1d9l+XUn2rSwiCLp3jDmW+Eewqr4xx4NsDq54A5Cu2eVLofFgcuxeGNI00IR6nkzHzP9qiFB3xmqRL8sx1jSB60S442oGFYCuNu3bO5Q2qkWjW/VmwPSqq5dd8chVPfcdJ2B+lVj35xjNDaMkT4lc5OBSBTzo0UTsdlJ9Ty+tOxWAG8hz6Ly+Zq0YN9EsmWEO2LcI4dJK/gGw5s3wj/erGSN4/hGJYmSRP5o2DqQeoytP216qgKuAB0Gwp3Usow3yI+Iexq/hVTT5OP8VbprgzvaVR95kkX4Jz95jPmk+ZB9CWX3U0pw3h01xIIbeNpXIJ0rjIAxkkkgAbjcnqKs+JWbCIxkZaAtLCejQu3+tHj+FyHA54Zh61q7vicXc2fGLCJI3tmEVzDEAq6H2ZTjH4mIBP8A3qtXfDLa9TnlGmZnhPAliv47TiaOiuSo0tpV2O0ZDjmhOB4SDkjJGCK1QtxwzioQeG0vAFX8qODgDJ/K7Y9pvStnxm44feQRC5xonK907eEK7LlMSc42Izg8sgg8wCj237ONcWRgYmSaMB43YAM7oCMNjbLrkHpk5wMUN99gKLhnHrq14j90vpNcUzARMVVQNRxEyFQNifAQc4PtkrcfsYoL2Sym8NpxIBwR/wBnugcLKo6DUVz6Sb7LTvCb61vLO2vL4gNZyYZnYJ/qLjGvqQ2I30j8QxvuDjftA7RJf3CdwpMaApHlTrkZyMkJz3woA57euKKVszNNY9ohacOmsbmYw3cHfQII95cgaonQfkwygMcbDzr59ZTzktHC0pafwusRcvNuWwwXdzzPXmfM1t+z/wBlt1dMJ752gU4LBjru38s6shNsbtk/w19Z4B2btrJdNtEqEjDOfFM/8zncj05DoBW3qNgPhnaHsfd29vHdXEaIPDGyIQXRdhG8gXYajkZznJXO5rMFa/Vl3bJLG8UqhkkVkdTyKsMEV+Z+0XCHs7mW1fJ7tsKx/Gh3R/mpGfI5HSnxTvgDRVijI1Rkj2yKilWAW3DpNiPI5+tPCWqeykw3uCP7f1p0yVxahe1ZSA2ZaiGpdGzTsEVQooTjqeqmUhoUkVZoxGOnoo9qXgWnohtSUKzD2lzirqG92rq6jFlZIMb2uW9rq6mbFo0XZiz75mdjhI8FupJPJcfKhdoeI6m7qMaVydhtuTkn3Jrq6vn9RJ5dZ4culVfOjYu2/cLWEIxltlXnjmT5CrP72cYHhUcgv+b11dXrZHXsro6MMU+WVfFeIaF/z61nDfMPEP1rq6onbHor7/imVxjFVsbsxwP3rq6rRiiM5NDkNsB8W/7U3GFHJR9K6uq0Ukcs5N9sKZqDJLXV1Oc7IRE5q94ca6upkTZouGcIW4kUFirRh2TGMHI0srZHIgn5gVl7mIcOu3hkybadcSKOiNkZAH4kOeXT15dXUltZ0vfx92aL5Zr+F20SW9xwniD+BUeeGUKSe4LDVkKDh0kIblvr25YrKcD7e3tuptI2S4XVohaZSWUasKUywwpGMK2dORyxiurq7IcpthkuS34b9mNxPJ3t7KItbGRljCtKWfJJ8P8ApoTnpq9q+l9leyVpZ728ID4wZZPHMfMaz8I25LgeldXVJzbDRpaHFIHB0HO5HI4yK9rqxjAfZ323nuG+7X6qJpBNLA8YARkjkdJI2UfCUZGwT8S89xlkfts4KGijv1xqjIil8zG58B9dLnH/ALh8q8rqOJ+0jM+Rwz4yDRJF8q6urtTJnRNgg+RqxNeV1c+oXCHgMWyVcWsVdXVzoZlkkO1L3MddXVmZCkZwacjkrq6pBZ//2Q==" alt="Neeraj Chopra">
                </div>
                <div class="news-content">
                    <span class="news-date">May 18, 2023</span>
                    <h2>Neeraj Chopra Breaks National Javelin Record Again</h2>
                    <p>Olympic champion Neeraj Chopra threw 89.94m to break his own national record at the Doha Diamond League.</p>
                </div>
            </article>
        </div>
        
        
    </div>
</section>

<?php include 'includes/footer.php'; ?>