<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sports India | <?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header class="main-header">
        <div class="container">
            <div class="logo">
                <img src="assets/images/logo.png" alt="Sports India">
                <h1>Sports India</h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php" <?php if($currentPage == 'home') echo 'class="active"'; ?>>Home</a></li>
                    <li><a href="news.php" <?php if($currentPage == 'news') echo 'class="active"'; ?>>News</a></li>
                    <li><a href="players.php" <?php if($currentPage == 'players') echo 'class="active"'; ?>>Players</a></li>
                    </ul>
            </nav>
            <div class="mobile-menu">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </header>