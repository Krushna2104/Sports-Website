<?php
$currentPage = 'players';
$pageTitle = 'Indian Sports Stars - Cricket, Hockey & More';
include 'includes/header.php';
?>

<section class="players-page">
    <div class="container">
        <h1 class="page-title">Indian Sports Stars</h1>
        
        <div class="players-intro">
            <p>India has produced numerous world-class athletes across various sports. Here are some of our most celebrated sports personalities.</p>
        </div>
        
        
        <div class="players-grid">
            <div class="player-card" data-category="cricket">
                <img src="assets/images/player-kohli.jpg" alt="Virat Kohli">
                <div class="player-info">
                    <h3>Virat Kohli</h3>
                    <p>Cricket - Batsman</p>
                    <div class="player-stats">
                        <div class="stat">
                            <span class="stat-number">70</span>
                            <span class="stat-label">Centuries</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">12,000+</span>
                            <span class="stat-label">Runs</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card" data-category="cricket">
                <img src="assets/images/player-dhoni.jpg" alt="MS Dhoni">
                <div class="player-info">
                    <h3>MS Dhoni</h3>
                    <p>Cricket - Wicketkeeper</p>
                    <div class="player-stats">
                        <div class="stat">
                            <span class="stat-number">3</span>
                            <span class="stat-label">ICC Titles</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">10,000+</span>
                            <span class="stat-label">ODI Runs</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card" data-category="cricket">
                <img src="assets/images/player-rohit.jpg" alt="Rohit Sharma">
                <div class="player-info">
                    <h3>Rohit Sharma</h3>
                    <p>Cricket - Batsman</p>
                    <div class="player-stats">
                        <div class="stat">
                            <span class="stat-number">3</span>
                            <span class="stat-label">Double Centuries</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">264</span>
                            <span class="stat-label">Highest ODI Score</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card" data-category="hockey">
                <img src="assets/images/player-dhyan.jpg" alt="Dhyan Chand">
                <div class="player-info">
                    <h3>Dhyan Chand</h3>
                    <p>Hockey - Forward</p>
                    <div class="player-stats">
                        <div class="stat">
                            <span class="stat-number">3</span>
                            <span class="stat-label">Olympic Golds</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">400+</span>
                            <span class="stat-label">Goals</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card" data-category="other">
                <img src="assets/images/player-neeraj.jpg" alt="Neeraj Chopra">
                <div class="player-info">
                    <h3>Neeraj Chopra</h3>
                    <p>Athletics - Javelin</p>
                    <div class="player-stats">
                        <div class="stat">
                            <span class="stat-number">1</span>
                            <span class="stat-label">Olympic Gold</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">89.94m</span>
                            <span class="stat-label">Personal Best</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card" data-category="other">
                <img src="assets/images/player-sindhu.jpg" alt="PV Sindhu">
                <div class="player-info">
                    <h3>PV Sindhu</h3>
                    <p>Badminton</p>
                    <div class="player-stats">
                        <div class="stat">
                            <span class="stat-number">1</span>
                            <span class="stat-label">Olympic Silver</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">2</span>
                            <span class="stat-label">World Championships</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card" data-category="other">
                <img src="assets/images/player-anand.jpg" alt="Viswanathan Anand">
                <div class="player-info">
                    <h3>Viswanathan Anand</h3>
                    <p>Chess</p>
                    <div class="player-stats">
                        <div class="stat">
                            <span class="stat-number">5</span>
                            <span class="stat-label">World Titles</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">2817</span>
                            <span class="stat-label">Peak Rating</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="player-card" data-category="hockey">
                <img src="assets/images/player-manpreet.jpg" alt="Manpreet Singh">
                <div class="player-info">
                    <h3>Manpreet Singh</h3>
                    <p>Hockey - Midfielder</p>
                    <div class="player-stats">
                        <div class="stat">
                            <span class="stat-number">1</span>
                            <span class="stat-label">Olympic Medal</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">250+</span>
                            <span class="stat-label">Caps</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>